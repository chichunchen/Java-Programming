import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.* ;
import javax.swing.event.*;

public class MenuPanel extends JPanel implements ActionListener
{
	private JFrame frame;
	private JFrame menuFrame;
	private JButton enter;
	private JTextField inputBox;
	private JButton[] buttons;
	private static final String[] btnNames = {"Tips", "Rank", "Option", "Exit"};
	private JLabel nameLable;
	private String playerName;
	private static final String[] backgroundPath = {"Image/background1.png", "Image/background2.png", "Image/background3.png", "Image/background4.png"};
	private Image backgroundImage;
	private JButton craftButton[];
	private static final String[] craftPath = {"Image/craft1.png", "Image/craft2.png", "Image/craft3.png"};
	private static final String[] craftTip = {"HP:2 Speed:2", "HP:1 Speed:3", "HP:3 Speed:1"};
	
	public MenuPanel( JFrame mframe )
	{
		setLayout( null );

		menuFrame = mframe;

		Random randomGenerator = new Random();
		loadBackgroundImage( backgroundPath[ randomGenerator.nextInt( backgroundPath.length ) ] );

		nameLable = new JLabel( "Space Shooter" );
		nameLable.setForeground(Color.white);
		nameLable.setFont( new Font("PLAIN", Font.PLAIN, 80) );
		add(nameLable);

		inputBox = new JTextField("Your name");
		inputBox.setFont( new Font("PLAIN", Font.PLAIN, 20) );
		add(inputBox);

		buttons = new JButton[ btnNames.length ];
		for (int i = 0; i < btnNames.length; i++) 
		{
			buttons[ i ] = new JButton( btnNames[i] );
			buttons[ i ].setFont(new Font("Arial", Font.PLAIN, 28));
			buttons[ i ].addActionListener( this );
			add( buttons[ i ] );
		}

		loadCraftImage();

		nameLable.setBounds(130, 20, 730, 150);
		inputBox.setBounds(150, 260, 180, 50);
		buttons[0].setBounds(170, 320, 140, 50);
		buttons[1].setBounds(170, 380, 140, 50);
		buttons[2].setBounds(170, 440, 140, 50);
		buttons[3].setBounds(170, 500, 140, 50);


		craftButton[0].setBounds(450, 230, 100, 100);
		craftButton[1].setBounds(450, 340, 100, 100);
		craftButton[2].setBounds(450, 450, 100, 100);
	}

	public void actionPerformed(ActionEvent event)
	{
		playerName = inputBox.getText();

		if(event.getSource() == buttons[0]) //tip
		{	
			menuFrame.remove( this );
			Tips tips = new Tips( menuFrame );
			menuFrame.add( tips );
			menuFrame.revalidate();
		}
		else if (event.getSource() == buttons[1]) //Rank
		{			
			menuFrame.remove( this );
			Rank rank = new Rank( menuFrame );
			menuFrame.add( rank );
			menuFrame.revalidate();
		}
		else if (event.getSource() == buttons[2]) //Option
		{		
			
		}
		else if (event.getSource() == buttons[3]) //exit
		{		
			System.exit(0); 
		}

		//////////////////////////////////////////////////////////////////////////////////

		for (int i = 0; i < craftButton.length; i++) 
		{
			if(event.getSource() == craftButton[i]) 
			{
				if(playerName.length() > 0 && playerName.equals("Your name") == false) 
				{
					frame = new JFrame( "Space Shooter" );
					
					frame.add( new Board(playerName, i+1, frame) );
				
					frame.setSize(800, 600);
					frame.setResizable(false);
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
					frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				}
				else 
				{
					JOptionPane.showMessageDialog(frame, "Input your name!");
				}
			}
		}
	}

	private void loadBackgroundImage(String image) 
	{
        String imagePath = image;
        ImageIcon ii = new ImageIcon(this.getClass().getResource(imagePath));
        backgroundImage = ii.getImage();
    }

    private void loadCraftImage() 
    {
    	craftButton = new JButton[ craftPath.length ];
		Icon craftIcon;

		for (int i = 0; i < craftPath.length; i++) 
		{
			craftIcon = new ImageIcon( this.getClass().getResource( craftPath[ i ] ) );

			craftButton[ i ] = new JButton( craftIcon );
			craftButton[ i ].setBackground(Color.BLACK);
			craftButton[ i ].setOpaque(true);
			craftButton[ i ].setBorderPainted(false);
			craftButton[ i ].setForeground(Color.WHITE);
			craftButton[ i ].setToolTipText(craftTip[ i ]);
			craftButton[ i ].addActionListener( this );
			add( craftButton[ i ] );
		}

    }

    public void paintComponent(Graphics g) 
    {
    	super.paintComponent(g);
        Graphics2D g2d = (Graphics2D)g;

    	g2d.drawImage(backgroundImage, 0, 0, this);
    }
}

