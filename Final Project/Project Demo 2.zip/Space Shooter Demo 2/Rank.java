
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.* ;
import javax.swing.event.*;
import java.io.*;

public class Rank extends JPanel implements ActionListener
{
	private JFrame menuFrame;

	public String fromRecordFile;

	public ArrayList<String> playerName;
    public ArrayList<String> craftModelIndex;
    public ArrayList<Integer> stage;
    public ArrayList<Integer> score;
    public ArrayList<Float> time; 

    private JButton back;

	public Rank( JFrame mframe )
	{
		menuFrame = mframe;

		playerName = new ArrayList<String>();
		craftModelIndex = new ArrayList<String>();
		stage = new ArrayList<Integer>();
		score = new ArrayList<Integer>();
		time = new ArrayList<Float>();

		back = new JButton("BACK");
		back.addActionListener( this );
		add(back);

		readRecord();
	}

	public void readRecord()
	{
		try
		{
			FileInputStream fstream  = new FileInputStream( "Records.txt" );
			DataInputStream in = new DataInputStream( fstream );
          	BufferedReader br = new BufferedReader( new InputStreamReader(in) );
          	String strLine;          	

          	while( (strLine = br.readLine()) != null )
          	{
          		String[] tokens = strLine.split(" ");
          		
          		playerName.add( tokens[ 0 ] );
          		craftModelIndex.add( tokens[ 1 ] );
          		stage.add( Integer.valueOf( tokens[ 2 ] ) );
          		score.add( Integer.valueOf( tokens[ 3 ] ) );
          		time.add( Float.valueOf( tokens[ 4 ] ) );
          	}
          
          	in.close();
		}
		catch( Exception e )
		{
			System.err.println("Error: " + e.getMessage());
		}
	}

	public void printRecord()
	{
		System.out.println(time.get(3));
	}

	public String scoreSort()
	{
		String result = "";

		ArrayList<Integer> nstore = new ArrayList<Integer>( score );
		Collections.sort(score);
		Collections.reverse(score);
		int[] indexes = new int [ score.size() ];

		for ( int n = 0; n < score.size(); ++n) 
		{
			indexes[n] = nstore.indexOf( score.get(n) );	
		}

		for ( int i = 0; i < score.size() && i < 10; ++i) 
		{
			result += ( String.format( "%-5s", i + 1 )
						+ String.format( "%-15s", playerName.get( indexes[ i ] ) ) 
						+ String.format( "%-10s", craftModelIndex.get( indexes[ i ] ) ) 
						+ String.format( "%-10s", stage.get( indexes[ i ] ) )
						+ String.format( "%-10s", score.get( i ) )
						+ String.format( "%-10s", time.get( indexes[ i ] ) )
						+ "\n" );
		}

		return result;
	}

	public void paintComponent( Graphics g )
	{
		super.paintComponent( g );
		setBackground(Color.black);

		g.setColor(Color.white);
		g.setFont( new Font("Helvetica", Font.PLAIN, 60) );
		g.drawString( "Rank #10", 280, 100 );
		
		g.setFont( new Font("Helvetica", Font.PLAIN, 32) );
		g.drawString( "NO   Name      CraftID   Stage     Score     Time", 50, 175);

		g.setFont( new Font("Helvetica", Font.PLAIN, 32) );
		drawString( g, scoreSort(), 50, 200 );
	}

	private void drawString(Graphics g, String text, int x, int y) 
	{ 
        for ( String line : text.split("\n") )
        	g.drawString(line, x, y += g.getFontMetrics().getHeight());
    }

	public void actionPerformed( ActionEvent event )
	{
		if ( event.getSource() == back ) 
		{
			menuFrame.remove( this );
			menuFrame.add( new MenuPanel( menuFrame ) );
			menuFrame.revalidate();
		}
	}
}