
import java.awt.*;
import javax.swing.*;

public class Item extends SpaceObject 
{
    private int width;
    private int height;
    private int type;
    private static final String[] itmeImagePath = { "Image/health.png", "Image/star.png", "Image/Missile_strengthen.png" };

    public Item(int x, int y, int n) 
    {
        super(x, y);
        type = n;
        setType();
    }

    public void setType()
    {
    	if ( type == 0 )		// add hp 
    	{
    		setImage( itmeImagePath[ type ] );
	        setHp(2);
	        setSpeed(1);
	        setPoint(50);
    	}
    	else if ( type == 1 )	// add speed 
    	{
    		setImage( itmeImagePath[ type ] );
	        setHp(1);
	        setSpeed(2);
	        setPoint(50);
    	}
    	else if ( type == 2 ) // change the missile mode
    	{
    		setImage( itmeImagePath[ type ] );
	        setHp(1);
	        setSpeed(3);
	        setPoint(50);
    	}
    }

    public int getType()
    {
        return type;
    }

    public void move() 
    {
        setX( getX() - getSpeed() );
    }
}