
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;
import java.util.Random;
import java.text.*;

public class Board extends JPanel implements ActionListener {

    private JFrame frame;
    private Timer timer;
    private NormalCraft craft;
    private int craftModelIndex;
    private Image spaceImage;
    private long StartTime;
    private long ProcessTime;
    private String currentTime;
	private int X1;
	private int X2;
    private static final String[] backgroundImage = {"Image/space1.png", "Image/space2.png", 
                                                    "Image/space3.png", "Image/space4.png", 
                                                    "Image/space5.png", "Image/space6.png"};
    private ArrayList<Stone> stones;
    private ArrayList<EnemyCraft> enemyCraft;
    private ArrayList<Item> items;
    private String playerName;
    private boolean ingame;
    private int stage;
    private int score;

    private int[][] stonePos;
    private int[][] eCraftPos;
    private int[][] itemPos;

    private BackgroundMusic backgroundMusic;
    

    public Board( String name, int craftIndex, JFrame f) 
    {	
		X1 = 0;
		X2 = 794;

        ingame = true;

        setPlayerName( name );

        backgroundMusic = new BackgroundMusic();
	
        addKeyListener(new TAdapter());
        setFocusable(true);
        setDoubleBuffered(true);
        frame = f;

        setCraftModelIndex( craftIndex );
        reset();
        loadBackgroundImage(backgroundImage[ getStage() - 1 ]);

        timer = new Timer(5, this);
        timer.start();
    }

    public void initStones( int s ) 
    {
        stones = new ArrayList<Stone>();

        int stoneNum = s + 20;
        stonePos = new int [stoneNum][2]; 
        Random randomGenerator = new Random();

        for (int i = 0; i < stoneNum; ++i) 
        {
            for (int j = 0; j < 2; ++j) 
            {
                if (j == 0) {
                    stonePos[i][j] = randomGenerator.nextInt(2500) + 1000;
                }
                else {
                    stonePos[i][j] = randomGenerator.nextInt(570);
                }
            }
        }

        for (int i = 0; i < stonePos.length; ++i) 
        {
            stones.add( new Stone(stonePos[i][0], stonePos[i][1]) );
        }
    }

    public void initEnemyCraft( int n ) 
    {
        enemyCraft = new ArrayList<EnemyCraft>();

        int eCraftNum = 1 + (n / 2);
        eCraftPos = new int [eCraftNum][2];
        Random randomGenerator = new Random();

        for (int i = 0; i < eCraftNum; ++i) 
        {
            for (int j = 0; j < 2; ++j) 
            {
                if (j == 0) 
                {
                    eCraftPos[i][j] = randomGenerator.nextInt(2500) + 1000;
                }
                else {
                    eCraftPos[i][j] = randomGenerator.nextInt(500) + 40;
                }
            }
        }

        for (int i = 0; i < eCraftPos.length; ++i) 
        {
            enemyCraft.add( new EnemyCraft( eCraftPos[i][0], eCraftPos[i][1], randomGenerator.nextInt( stage ) ) );
        }
    }

    public void initItems( int n )
    {
        items = new ArrayList<Item>();
        Random randomGenerator = new Random();


        int itemNum = randomGenerator.nextInt(n);
        itemPos = new int [itemNum][2];

        for (int i = 0; i < itemNum; ++i) 
        {
            for (int j = 0; j < 2; ++j) 
            {
                if (j == 0) 
                {
                    itemPos[i][j] = randomGenerator.nextInt(2500) + 1000;
                }
                else {
                    itemPos[i][j] = randomGenerator.nextInt(500) + 40;
                }

            }
        }

        for (int i = 0; i < itemPos.length; ++i) 
        {
            items.add( new Item( itemPos[i][0], itemPos[i][1], randomGenerator.nextInt( 3 ) ) );
        }
    }

    public void setGameStory( int s )
    {
        initStones( s );
        initEnemyCraft( s );
        initItems( s );
        
    }

    private void backgroundMusic() {}

    private void loadBackgroundImage( String imageName ) 
    {
        String path = imageName;
        ImageIcon ii = new ImageIcon(this.getClass().getResource(path));
        spaceImage = ii.getImage();
    }

    public void setStage( int s ) 
    {
        stage = s;
    }

    public int getStage() 
    {
        return stage;
    }

    public void setScore( int x ) 
    {
        score = x;
    }

    public int getScore() 
    {
        return score;
    }

    public void addScore( int s )
    {
        score += s;
    }

    public void setPlayerName( String pName )
    {
        playerName = pName;
    }

    public String getPlayerName()
    {
        return playerName;
    }

    public void setCraftModelIndex( int n )
    {
        craftModelIndex = n;
    }

    public int getCraftModelIndex()
    {
        return craftModelIndex;
    }

    public void pause()
    {
        if (ingame) 
        {
            timer.stop();
            backgroundMusic.stop();
        }
    }

    public void resume()
    {
        timer.restart();
        backgroundMusic.gameMusic();
    }

    public void updateRank()
    {
        Records records = new Records(this);

        records.setOutput();
        records.writeFile();
    }

    public void reset()
    {
        craft = new NormalCraft( craftModelIndex );
        craft.setVisible(true);

        //backgroundMusic.stop();
        backgroundMusic.gameMusic();
        
        ingame = true;
        stage = 1;
        setScore( 0 );
        setGameStory( stage );
        StartTime = System.currentTimeMillis();
    }

    public void back2Menu() 
    {
        backgroundMusic.stop();
        frame.dispose();
    }

    public void restart()
    {
        if (ingame == false) 
        {
            reset();
        }
    }

    public void paintComponent(Graphics g) 
    {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D)g;

        // Draw space background image
        g2d.drawImage(spaceImage, X1, 0, this);
		g2d.drawImage(spaceImage, X2, 0, this);

        // Draw Craft image
        if(ingame) 
        {
            // level up
            if(enemyCraft.size() < 1) 
            {
                stage++;
                setGameStory( getStage() );
                if(getStage() < backgroundImage.length)
                {
                    loadBackgroundImage(backgroundImage[ getStage() - 1 ]);
                }
                else
                {
                    loadBackgroundImage(backgroundImage[ backgroundImage.length - 1 ]);
                }
            }

            g2d.drawImage(craft.getImage(), craft.getX(), craft.getY(), this);
            
            // draw Stage
            g2d.setColor( Color.WHITE );
            g2d.setFont( new Font("Helvetica", Font.PLAIN, 28) );
            g2d.drawString("Stage " + getStage(), 340, 60);
        }
        // Game Over!
        else 
        {
            String msg = "Game Over";
            Font gameOverFont = new Font("Helvetica", Font.BOLD, 36);
            FontMetrics metr = this.getFontMetrics(gameOverFont);

            g2d.setColor(Color.white);
            g2d.setFont(gameOverFont);
            g2d.drawString(msg, (800 - metr.stringWidth(msg)) / 2, 600 / 2);

            g2d.setFont( new Font( "Helvetica", Font.PLAIN, 28 ) );
            g2d.drawString("Click Enter to Restart / Q to Exit", 190, 100);
        }


        // Draw missile 
        ArrayList ms = craft.getMissiles();
        for (int i = 0; i < ms.size(); i++ ) 
        {
            Missile m = (Missile) ms.get(i);
            g2d.drawImage(m.getImage(), m.getX(), m.getY(), this);
        }
        // Draw stone 
        for (int i = 0; i < stones.size(); ++i) 
        {
            Stone s = (Stone)stones.get(i);
            g2d.drawImage( s.getImage(), s.getX(), s.getY(), this );
        }
        // Draw enemy craft 
        for (int i = 0; i < enemyCraft.size(); ++i) 
        {
            EnemyCraft ec = (EnemyCraft)enemyCraft.get(i);
            g2d.drawImage( ec.getImage(), ec.getX(), ec.getY(), this );
        }

        // Draw Items
        for (int i = 0; i < items.size(); ++i) 
        {
            Item it = (Item)items.get(i);
            g2d.drawImage( it.getImage(), it.getX(), it.getY(), this );    
        }

        // Print processing time
        g2d.setColor( Color.WHITE );
        g2d.setFont( new Font("Helvetica", Font.PLAIN, 28) );
        setTime(ProcessTime);
        g2d.drawString("Time: " + getTime(), 620, 30);

        // Print score
        g2d.setColor( Color.WHITE );
        g2d.setFont( new Font("Helvetica", Font.PLAIN, 28) );
        g2d.drawString("Score: " + getScore(), 620, 60);

        // Print craft health
        g2d.setColor( Color.WHITE );
        g2d.setFont( new Font("Helvetica", Font.PLAIN, 28) );
        g2d.drawString("Life", 20, 30);
        for (int i = 0; i<craft.getHp(); ++i) 
        {
            g2d.setColor( Color.WHITE );
            g2d.fillRect(120+(i*20), 10, 20, 20);
        }

        // Print craft Speed
        g2d.setColor( Color.WHITE );
        g2d.setFont( new Font("Helvetica", Font.PLAIN, 28) );
        g2d.drawString("Speed", 20, 60);
        g2d.setColor( Color.WHITE );
        g2d.fillRect(120, 40, 20 * craft.getSpeed(), 20);

        // 
        Toolkit.getDefaultToolkit().sync();
        g.dispose();
    }

    public void setTime(long recordTime) 
    {
        float a = (float) recordTime / 1000;
        NumberFormat nf = NumberFormat.getInstance();
        nf.setMaximumFractionDigits( 2 ); 

        currentTime = String.valueOf(nf.format(a));   
    }

    public String getTime()
    {
        return currentTime;
    }

    public void actionPerformed(ActionEvent e) 
    {
        if(ingame)
            ProcessTime = System.currentTimeMillis() - StartTime; 
		

        // set the location of space background
		X1 -= 1;
		X2 -= 1;
		if(X1 < -794) {
			X1 = 794;
		}
		if(X2 < -794) {
			X2 = 794;
		}
        ////////////////////////////////////////////////////////////
		
        // move the missiles
        ArrayList ms = craft.getMissiles();

        for (int i = 0; i < ms.size(); i++) 
        {
            Missile m = (Missile) ms.get(i);
            if (m.getHp() > 0) 
                m.move();
            else ms.remove(i);
        }

        // move stones
        for (int i = 0; i < stones.size(); ++i) 
        {
            Stone s = (Stone)stones.get(i);
            if(s.getHp() > 0)
                s.move();
            else 
            {
                stones.remove(i);
            }
        }

        // move enemy craft
        for (int i = 0; i < enemyCraft.size(); ++i) 
        {
            EnemyCraft ec = (EnemyCraft)enemyCraft.get(i);
            if(ec.getHp() > 0)
                ec.move();
            else 
            {
                enemyCraft.remove(i);
            }
        }

        // move items
        for (int i = 0; i < items.size(); ++i) 
        {
            Item it = (Item)items.get(i);
            if(it.getHp() > 0)
                it.move();
            else 
            {
                items.remove(i);
            }    
        }

        craft.move();
        checkCollisions();
        repaint();  
    }

    public void checkCollisions() 
    {
        Rectangle rCraft = craft.getBounds();

        // collision between craft and stone
        if(craft.getHp() > 0) 
        {
            for (int j = 0; j < stones.size(); ++j) 
            {
                Stone s = (Stone)stones.get(j);
                Rectangle rStone = s.getBounds();

                if (rCraft.intersects(rStone)) 
                {
                    s.subHp(1);
                    craft.subHp(1);

                    if (s.getHp() < 1) 
                    {
                        stones.remove(s);
                    }

                    if (craft.getHp() < 1) 
                    {
                        craft.setVisible(false);
                        ingame = false;
                        backgroundMusic.stop();
                        //backgroundMusic.gameOverMusic();
                        // game over
                    }
                }

                if (j < enemyCraft.size()) 
                {
                    EnemyCraft ec = (EnemyCraft)enemyCraft.get(j);
                    Rectangle rECraft = ec.getBounds();   

                    if (rCraft.intersects(rECraft)) 
                    {
                        ec.subHp(1);
                        craft.subHp(1);

                        if (ec.getHp() < 1) 
                        {
                            enemyCraft.remove(ec);
                        }

                        if (craft.getHp() < 1) 
                        {
                            craft.setVisible(false);
                            ingame = false;
                            backgroundMusic.stop();
                            //backgroundMusic.gameOverMusic();
                            // game over
                        }
                    }
                }

                if (j < items.size()) 
                {
                    Item it = (Item)items.get(j);
                    Rectangle rItem = it.getBounds();

                    if(rCraft.intersects(rItem))
                    {
                        it.subHp(1);

                        if (it.getHp() < 1) 
                        {
                            items.remove(it);   
                            if (it.getType() == 0) 
                            {
                                craft.addHp(1);
                            }
                            else if (it.getType() == 1) 
                            {
                                craft.addSpeed(1);    
                            }
                            else if (it.getType() == 2) 
                            {
                                craft.addMissileBoost(1);
                            }
                        }
                    }    
                }
            }
        }

        ArrayList ms = craft.getMissiles();

        // collision between missile and stone
        for (int i = 0; i < ms.size(); ++i) 
        {
            Missile m = (Missile)ms.get(i);
            Rectangle rMissile = m.getBounds();

            for (int j = 0; j < stones.size(); ++j) 
            {
                Stone s = (Stone)stones.get(j);
                Rectangle rStone = s.getBounds();

                if(rMissile.intersects(rStone) && m.getX() < 820) 
                {
                    s.subHp(1);
                    m.subHp(1);
                    addScore( s.getPoint() + stage * 5 );

                    if (s.getHp() < 1) 
                    {
                        stones.remove(s);
                    }

                    if (m.getHp() < 1) 
                    {
                        ms.remove(m);
                    }
                }

                if (j < enemyCraft.size()) 
                {
                    EnemyCraft ec = (EnemyCraft)enemyCraft.get(j);
                    Rectangle rECraft = ec.getBounds();   

                    if (rMissile.intersects(rECraft) && m.getX() < 820) 
                    {
                        ec.subHp(1);
                        m.subHp(1);
                        addScore( ec.getPoint() + stage * 10 );

                        if (ec.getHp() < 1) 
                        {
                            enemyCraft.remove(ec);
                        }

                        if (m.getHp() < 1) 
                        {
                            ms.remove(m);
                        }
                    }
                }
            }
        }
    }

    private class TAdapter extends KeyAdapter 
    {
        public void keyReleased(KeyEvent e) 
        {
            craft.keyReleased(e);
        }

        public void keyPressed(KeyEvent e) 
        {
            craft.keyPressed(e);

            int key = e.getKeyCode();
            if (key == KeyEvent.VK_P) 
            {
                pause();
            }
            else if (key == KeyEvent.VK_R) 
            {
                resume();
            }
            else if (key == KeyEvent.VK_ENTER) 
            {
                updateRank();
                restart();    
            }
            else if (key == KeyEvent.VK_Q) 
            {
                if(score != 0)
                    updateRank();
                back2Menu();
            }
        }
    }

}