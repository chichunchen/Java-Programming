
import java.io.*;
import java.net.URL;
import javax.sound.sampled.*;

public class BackgroundMusic 
{
	public Clip clip;

	public BackgroundMusic()
	{

	}

	public void menuMusic()
	{
		start( "" );
	}

	public void gameMusic()
	{
		start( "Audio/music_background.wav" );
	}

	public void gameOverMusic()
	{
		start( "Audio/End_of_Game.wav" );
	}

	public void start( String path )
	{
		try 
		{
            // Open an audio input stream.
         	URL url = this.getClass().getClassLoader().getResource( path );
         	AudioInputStream audioIn = AudioSystem.getAudioInputStream(url);
         	// Get a sound clip resource.
         	clip = AudioSystem.getClip();
         	// Open audio clip and load samples from the audio input stream.
	        clip.open(audioIn);
	        //clip.start();
	        clip.loop(Clip.LOOP_CONTINUOUSLY);
      	} 
      	catch (UnsupportedAudioFileException e) 
      	{
         	e.printStackTrace();
      	} 
      	catch (IOException e) 
      	{
         	e.printStackTrace();
      	} 
      	catch (LineUnavailableException e) 
      	{
            e.printStackTrace();
      	}
	}

	public void stop()
	{
		if (clip.isRunning()) 
			clip.stop();
	}
}